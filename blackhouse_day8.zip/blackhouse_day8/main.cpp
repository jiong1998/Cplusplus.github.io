#include <iostream>
#include <string>
using namespace std;
template <typename T>
void mySwap(T&a,T&b)
{
    T temp=a;
    a=b;
    b=temp;
}
//利用函数模板实现对char类型和int类型数组的从大到小排序，使用选择排序
template <class T>
void mySort(T arr[], int len)
{
    int i,j;
    for(i=0;i<len-1;++i)
    {
        int max=i;
        for(j=i+1;j<len;++j)
        {
            if(arr[j]>arr[max])
                max=j;
        }
        if(max!=i)
        {
            //交换
            mySwap(arr[max],arr[i]);
        }
    }
}

//利用具体化技术解决模板的局限性问题

class Person
{
public:
    Person(int age,string name)
    {
        this->m_age=age;
        this->m_name=name;
    }
    int m_age;
    string m_name;
};
void test1()
{
    int arr[]={12,5,123,14,6,1,4};
    int len=sizeof(arr)/sizeof(int);
    mySort(arr,len);
    for(int i=0;i<len;++i)
    {
        printf("%d\n", arr[i]);
    }
}

template <class T>
bool myCompare(T &a, T &b)
{
    if(a==b)
        return true;
    else
        return false;
}
template<> bool myCompare(Person & p1, Person & p2)
{
    if(p1.m_name==p2.m_name && p1.m_age==p2.m_age)
        return true;
    else
        return false;
}

void test2()
{
    int a=10,b=10;
    Person p1= Person(23,"小卢");
    Person p2= Person(22,"小卢");

    if(myCompare(p1,p2))
        cout<<"对"<<endl;
    else
        cout<<"错"<<endl;

}

//类模板
template <class NAMETYPE, class AGETYPE=int>
class Person1
{
public:
    Person1(NAMETYPE name, AGETYPE age)
    {
        this->m_name=name;
        this->m_age=age;
    }
    NAMETYPE m_name;
    AGETYPE m_age;
};

void test3()
{
    Person1<string> p1=Person1<string>("小卢",13);
    cout<<p1.m_name<<endl;
}
//类模板的类内声明，类外实现
template <class T1, class T2>
class Person2
{
public:
    Person2(T1 name, T2 age);
    void showPerson();
    T1 m_name;
    T2 m_age;
};
template <class T1, class T2>
Person2<T1,T2>::Person2(T1 name, T2 age)
{
this->m_name=name;
this->m_age=age;
}
template <class T1, class T2>
void Person2<T1,T2>::showPerson() //就算没有用到T1和T2，但是类模板的类外实现就得加上
{
    cout<<"姓名"<<this->m_name<<"年龄"<<this->m_age<<endl;
}


int main() {

    test3();
    return 0;
}
