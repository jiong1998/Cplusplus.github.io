//
// Created by jiong1998 on 2022/10/1.
//
#include <iostream>
#include "MyArray.h"
using namespace std;
MyArray::MyArray()//用户没有指定容量，则初始化为100
{
cout<<"创建数组成功！\n"<<endl;
this->mSize=0;
this->mCapacity=100;//默认无参的话就是100
this->pAdress=new int[100];
}

MyArray::MyArray(int capacity)//用户指定容量
{
    cout<<"创建数组成功！\n"<<endl;
    this->mSize=0;//当前有多少个元素
    this->mCapacity=capacity;//数组一共可容纳多少个元素
    this->pAdress=new int[capacity];
}

void MyArray::SetData(int pos, int val)//根据位置添加元素
{
    //pos算0
    //判断满了没
    if(this->mCapacity==this->mSize)
    {
        cout<<"数组以满，添加失败\n"<<endl;
        return;
    }
    //判断pos的位置是否在最后或者最后的后面
    if(pos>=this->mSize)
    {
        this->pAdress[this->mSize++]=val;
    }
    else
    {

        for(int index=this->mSize-1;index>=pos;index--)
        {
            this->pAdress[index+1]=this->pAdress[index];
        }
        this->pAdress[pos]=val;
        this->mSize++;
    }

}

int MyArray::GetData(int pos)//获得指定位置数据
{
    return this->pAdress[pos];
}

void MyArray::PushBack(int val)//尾插法
{
    if(this->mCapacity==this->mSize)
    {
        cout<<"数组以满，添加失败\n"<<endl;
        return;
    }
    this->pAdress[this->mSize++]=val;
    cout<<"添加成功！"<<"当前数组个数="<<this->mSize<<"\n"<<endl;
}


int MyArray::GetLength()//获取长度
{
    return this->mSize;
}


void MyArray::showArray()//输出整个数组
{
    if(this->mSize==0)
    {
        cout<<"数组为空\n"<<endl;
    }
    int i=0;
    cout<<"当前数组为："<<endl;
    while(i<mSize)
    {
        cout<<this->pAdress[i++]<<endl;
    }
    cout<<"\n"<<endl;
}
