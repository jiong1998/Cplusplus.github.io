#include <iostream>
using namespace std;

class Base
{
public:
    Base()
    {
        this->m_A=10;
    }
    int m_A;
};

class Son: public Base
{
public:
    Son()
    {
        this->m_A=20;
    }
    int m_A;
};

void test1()
{
    Son s1;
    cout<<s1.m_A<<endl;
    cout<<s1.Base::m_A<<endl;
}

int main() {
    test1();

    return 0;
}
