#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

class MyException//自己定义一个异常
{
public:
    void printError()
    {
        cout<<"我自己的异常"<<endl;
    }
};

int myDivision(int a, int b)//该函数作为抛出异常的函数
{
    if(b==0)
    {
//        throw 1;//抛出int类型的异常
//        throw 'a';//抛出char类型的异常
//        throw MyException();
        throw 3.14;//抛出double异常
    }
    return a/b;
}

void test()
{
    int a=10,b=0;
    try
    {
        myDivision(a,b);
    }
    catch(int)
    {
        cout<<"整数类型的异常捕获"<<endl;
    }
    catch(char)
    {
        cout<<"char类型的异常捕获"<<endl;
    }
    catch(MyException e)//抛出的异常可以是自定义数据类型
    {
        e.printError();
    }
    catch(...)//捕获任意类型的异常
    {
        cout<<"其他类型的捕获"<<endl;
        throw;//如果捕获的异常在当前不想处理，可以继续向上跑出，利用throw
    }
}

int test1()
{
    try
    {
        test();
    }
    catch(...)//下层不想处理的异常，抛给当层做处理
    {
        cout<<"其他类型异常捕获"<<endl;
    }
    return 0;
}

//多态实现异常类
class BaseException
{
public:
    virtual void printError()=0;
};

class NULLPointerException:public BaseException
{
public:
    virtual void printError()
    {
        cout<<"空指针异常"<<endl;
    }
};
class OutOfRangeException:public BaseException
{
public:
    virtual void printError()
    {
        cout<<"越界异常"<<endl;
    }
};

void dowork()//用来抛异常的函数
{
//    throw NULLPointerException();
    throw OutOfRangeException();
}
void test2()
{
    try
    {
        dowork();
    }
    catch(BaseException & e)
    {
        e.printError();
    }
}

//系统异常类的使用

//需求：对年龄做一个判断，若超出限制就抛出系统异常
class Person
{
public:
    Person(int age)
    {
        if (age<0 || age>150)
        {
            throw out_of_range("年龄超出界限");
        }
        else
        {
            m_Age=age;
        }
    }

    int m_Age;
};
void test3()
{
    try
    {
        Person p=Person(151);
    }
    catch(exception &e)//用基类的exception接住就行
    {
        cout<<e.what()<<endl;
    }
}

//需求：继承系统提供的父类异常类exception，编写自己的类。

class MyOutOfRangeException:public exception
{
public:
    MyOutOfRangeException(const char * str)
    {
        //char*可以隐式转化为string，反之不行
        this->m_errorInfo= str;
    }
    MyOutOfRangeException(string str)
    {
        this->m_errorInfo= str;
    }
    virtual const char* what() const
    {
        //将string转为const char *
        return m_errorInfo.c_str();
    }
    string m_errorInfo;
};

class Person1
{
public:
    Person1(int age)
    {
        if (age<0 || age>150)
        {
            throw MyOutOfRangeException("年龄超出界限");
        }
        else
        {
            m_Age=age;
        }
    }

    int m_Age;
};

void test5()
{
    try
    {
        Person1 p1=Person1(151);
    }
    catch (exception &e)
    {
        cout<<e.what()<<endl;
    }

}

int main() {
    test5();
    exception e;
}
