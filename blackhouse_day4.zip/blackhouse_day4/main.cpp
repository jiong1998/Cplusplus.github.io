#include <iostream>
using namespace std;
class A
{
public:
    static int m_A;
};

int A::m_A=10;

void test1()
{
    A a;
    a.m_A=20;
    cout<<a.m_A<<endl;

}

class ChairMan
{
public:
    static ChairMan * GetInstance()//
    {
        return singleMan;
    }
private:
    ChairMan(){}//将构造函数私有化，不允许创建对象
    ChairMan(const ChairMan & ){}//将拷贝构造函数私有化，不允许创建对象
    static ChairMan * singleMan;//限制可读不可写
};

ChairMan* ChairMan::singleMan=new ChairMan;//给指针类型为主席的赋予一个空间。注：静态成员变量只能全局初始化

void test2()
{
    ChairMan * c1=ChairMan::GetInstance();

}

class Person
{
public:
    void show()
    {
        cout<<"hello"<<endl;
    }
    void fix_age(int age)
    {
        M_age=age;
    }
    int M_age;

};
void test3()
{
    Person  p;
    p.fix_age(10);

}

//类内声明，类外实现
class Person1
{
public:
    Person1(int age);//构造函数
    void change_age(int age);
    void show_age();
    int M_age;
};
//构造函数的实现
Person1::Person1(int age)
{
    M_age=age;
}

void Person1::change_age(int age)
{
    M_age=age;
}
void Person1::show_age()
{
    cout<<"age="<<M_age<<endl;
}


void test4()
{
    Person1 p=Person1(11);
    p.show_age();
}
int main() {
    test4();
    return 0;
}
