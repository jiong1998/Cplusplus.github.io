#include <iostream>
using namespace std;
/*
 设计立方体类(Cube)，
 求出立方体的面积( 2*a*b + 2*a*c + 2*b*c )和体积( a * b * c)，
 分别用全局函数和成员函数判断两个立方体是否相等。
 */

class Cub
{
public:
    //长
    void set_L(int l)
    {
        L=l;
    }
    int get_L()
    {
        return L;
    }
    //宽
    void set_W(int w)
    {
        W=w;
    }
    int get_W()
    {
        return W;
    }
    //高
    void set_H(int h)
    {
        H=h;
    }
    int get_h()
    {
        return H;
    }
    //计算体积和表面积
    int calculateS()
    {
        return 2*L*W+2*L*H+2*W*H;
    }
    int calculateV()
    {
        return L*W*H;
    }

private:
    int L,W,H;
};

void test1()
{
    Cub c1;
    Cub c2;
    c1.set_L(10);
    c1.set_W(10);
    c1.set_H(10);
    c2.set_L(5);
    c2.set_W(5);
    c2.set_H(5);
    cout<<c1.calculateS()<<endl;
}

/*
设计一个圆形类（AdvCircle），和一个点类（Point），计算点和圆的关系。
假如圆心坐标为x0, y0, 半径为r，点的坐标为x1, y1：

 */

class Point
{
public:
    void set_point(int x,int y)
    {
        x0=x;y0=y;
    }
    int get_X()
    {
        return x0;
    }
    int get_Y()
    {
        return y0;
    }
private:
    int x0,y0;
};

class Circle
{
public:
    void set_r(float R)
    {
        r=R;
    }
    float get_r()
    {
        return r;
    }
    void set_center(Point p)
    {
        center_r=p;
    }
    void isIncircle(Point p)
    {
        float distance=(center_r.get_X()-p.get_X())*(center_r.get_X()-p.get_X())+(center_r.get_Y()-p.get_Y())*(center_r.get_Y()-p.get_Y());
        if(distance==r*r)
            cout<<"圆上"<<endl;
        else if(distance>r*r)
            cout<<"圆外"<<endl;
        if(distance<r*r)
            cout<<"圆内"<<endl;
    }
private:
    Point center_r  ;
    float r;

};

void test2()
{
    Point center;
    center.set_point(10,0);
    Circle c1;
    c1.set_center(center);
    c1.set_r(10);
    Point point;
    point.set_point(10,10);

    c1.isIncircle(point);
}

//探讨默认拷贝构造函数的浅拷贝问题
class Person
{
public:
    Person(char * name, int age)//构造函数
    {
        m_name=(char *) malloc(strlen(name)+1);
        strcpy(m_name,name);
        m_age=age;
    }
    Person(const Person & p)//拷贝构造函数
    {
        m_name=(char *) malloc(strlen(p.m_name)+1);
        strcpy(m_name,p.m_name);
        m_age=p.m_age;
    }
    ~Person()
    {
        cout<<"析构函数已调用"<<endl;
        free(m_name);
        m_name=NULL;
    }

    int m_age;
    char * m_name;
};

void test3()
{
    Person p1=Person("卢锦荣",20);
    Person p2=p1;
    cout<<p1.m_name<<"\n"<<p1.m_age<<endl;
    cout<<p2.m_name<<"\n"<<p2.m_age<<endl;
}

//new与delete

class Animal
{
public:
    Animal(int age,string name):m_age(age), m_name(name)
    {}
//    Animal()//无参构造函数
//    {
//    }
    int m_age;
    string m_name;
    ~Animal()
    {
        cout<<"析构函数调用"<<endl;
    }
};

void test4()
{
    Animal a1=Animal(15,"牛");
    Animal * a2=new Animal(17,"羊");
    cout<<a2->m_age<<"\n"<<a2->m_name<<endl;
    delete a2;
}
void test5() {
    int a[10]={};
}
int main() {
    test5();
    return 0;
}
