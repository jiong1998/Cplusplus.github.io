#include <iostream>
using namespace std;

const double PI = 3.14;

class Circle
{
public:
    //半径
    double c_R;

    //计算周长
    double caclulate_ZC()
    {
        return 2*PI*c_R;
    }
    //设置半径
};

class Stu
{
private:
    string name;
    string number;
public:
    void set_name(string names)
    {
        name=names;
    };
    void set_number(string numbers)
    {
        number=numbers;
    };

    string get_name()
    {
        return name;
    }
    string get_number()
    {
        return number;
    }

};

void test1()
{
    Stu S1;
    S1.set_name("卢锦荣");
    S1.set_number("2112106180");
    string name=S1.get_name();
    string number=S1.get_number();
    cout<<name<<"\n"<<number<<endl;
}

struct Person
{
    string name;
    void PersonEat()
    {
        cout<<name<<"eat something"<<endl;
    }
};

void test2()
{
    struct Person p;
    p.name="老王";
    p.PersonEat();
}




int main() {
    test2();
    return 0;
}
