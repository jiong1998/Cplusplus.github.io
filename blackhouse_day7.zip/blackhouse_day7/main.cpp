#include <iostream>
using namespace std;

class Animal
{
public:
    virtual void speak()
    {
        cout<<"动物在说话"<<endl;
    }
    int age=10;
};

class Cat:public Animal
{
public:
    void speak()
    {
        cout<<"小猫在说话\n"<<endl;
    }
    int gender;
};

void test1()
{
    Animal * animal=new Cat;
    Animal animal1=Cat();
    animal1.speak();
}

class Animal1
{
public:
    virtual void speak()
    {
        cout<<"动物在说话"<<endl;
    }
    virtual ~Animal1()=0;
};

Animal1::~Animal1()
{
    cout<<"Animal1的析构函数调用"<<endl;
}

class Cat1:public Animal1 {
public:
    virtual void speak() {
        cout << "小猫在说话" << endl;
    }

    ~Cat1()
    {
        cout<<"Cat的析构函数调用"<<endl;
    }
};

void test3()
{
    Animal1 * animal=new Cat1;
    animal->speak();
    delete animal;
}
//-------------------------
//抽象化三个类
class CPU
{
public:
    virtual void calculate()=0;
};

class VideoCard
{
public:
    virtual void display()=0;
};

class Memory
{
public:
    virtual void storage()=0;
};
//电脑类
class Computer
{
public:
    Computer(CPU * cpu, VideoCard* videocard, Memory * memory)
    {
        m_cpu=cpu;
        m_videocard=videocard;
        m_memory=memory;
    }
    CPU *m_cpu;
    VideoCard * m_videocard;
    Memory * m_memory;
    void dowork()
    {
        m_cpu->calculate();
        m_videocard->display();
        m_memory->storage();
    }
};
//定义不同厂商CPU、显卡、内存条
class InterCPU:public CPU
{
    virtual void calculate()
    {
        cout<<"这是因特尔cpu在计算"<<endl;
    }
};

class AppleCPU:public CPU
{
    virtual void calculate()
    {
        cout<<"这是苹果cpu在计算"<<endl;
    }
};

class InterVideoCard:public VideoCard
{
    virtual void display()
    {
        cout<<"这是因特尔显卡在显示"<<endl;
    }
};

class AppleVideoCard:public VideoCard
{
    virtual void display()
    {
        cout<<"这是苹果显卡在显示"<<endl;
    }
};

class InterMemory:public Memory
{
    virtual void storage()
    {
        cout<<"这是因特尔内存在存储"<<endl;
    }
};

class AppleMemory:public Memory
{
    virtual void storage()
    {
        cout<<"这是苹果内存在存储"<<endl;
    }
};

void test4()
{
    VideoCard * appleVC=new AppleVideoCard;
    CPU * applecpu=new AppleCPU;
    Memory * applememory= new AppleMemory;

    VideoCard * interVC=new InterVideoCard;
    CPU* intercpu=new InterCPU;
    Memory * intermemory=new InterMemory;

    Computer c1 =Computer(applecpu,interVC,applememory);
    c1.dowork();

}

int main() {
    test4();
    return 0;
}
